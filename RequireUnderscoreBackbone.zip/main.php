<!doctype html>
<html lang="en">
<head>
	<TITLE>Require -> JQuery -> Underscore -> Backbone</TITLE>
<?php include_once("templates/templates.php"); ?>

	<link rel="stylesheet" type="text/css" href="styles/main.css" />
</head>
<body>
		<script data-main="scripts/main" src="libs/require.min.js"></script>
</body>
</html>