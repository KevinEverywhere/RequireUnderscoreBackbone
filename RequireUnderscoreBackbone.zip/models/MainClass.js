define(['backbone'],
	function(Backbone) {
		/*
			Empty Class for holding any necessary globals
		*/
		var MainClass = Backbone.Model.extend({
		});
		return MainClass;
	}
);
